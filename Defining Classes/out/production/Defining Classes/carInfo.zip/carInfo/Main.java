package carInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        List<Cars> carsCollection = new ArrayList<>();
        for (int i = 0; i < n; i++) {
                String [] cars = scanner.nextLine().split(" ");
                String brand = cars[0];
                String model = cars[1];
                int hsP = Integer.parseInt(cars[2]);

            Cars car = new Cars();
            car.setBrand(brand);
            car.setModel(model);
            car.setHorsePower(hsP);

        carsCollection.add(car);
        }

        for (Cars cars : carsCollection) {
            System.out.println(cars.Car());
        }


    }
}
