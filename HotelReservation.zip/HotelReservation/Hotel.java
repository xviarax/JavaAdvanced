package HotelReservation;

public class Hotel {
}
